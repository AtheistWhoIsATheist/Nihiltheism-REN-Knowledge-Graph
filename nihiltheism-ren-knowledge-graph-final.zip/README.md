# Nihiltheism REN Knowledge Graph & Ingestion System

Interactive Nihiltheistic Hypermap & Knowledge Graph application featuring 730 preserved canonical nodes across 2 root branches, coupled with a multi-format bulk file ingestion system (.md, .txt, .pdf, .json, .csv), force-directed cosmic visualizer, and deterministic duplicate safety.

## Run Instructions
1. Install dependencies:
   ```bash
   npm install
   ```
2. Start the dev server:
   ```bash
   npm run dev
   ```
3. Run automated verification suite:
   ```bash
   npm test
   ```
4. Build for production:
   ```bash
   npm run build
   ```

## Invariant Ledger
- **P-001—P-005**: 100% Intact canonical corpus & topological hierarchy
- **IV1—IV16**: Multi-format ingestion, SHA-256 deduplication, atomic failure isolation
